import yt_dlp as youtube_dl
import os
import sys
from colorama import Fore, Style, init

# Initialize colorama
init()

def print_header():
    """Prints the header for the application."""
    print(Fore.CYAN + "=" * 36)
    print("      YouTube Video Downloader       ")
    print("=" * 36 + Style.RESET_ALL)

def print_footer():
    """Prints the footer for the application."""
    print(Fore.CYAN + "=" * 36)
    print("          Thank you for using        ")
    print("       the YouTube Downloader!       ")
    print("=" * 36 + Style.RESET_ALL)

def download_youtube_video():
    """Handles downloading of the YouTube video based on user input."""
    print_header()
    url = input(Fore.CYAN + "Enter the YouTube video URL: " + Style.RESET_ALL)

    # Options for yt-dlp
    ydl_opts = {
        'outtmpl': os.path.join(os.getcwd(), '%(title)s.%(ext)s'),
        'format': 'best',
        'progress_hooks': [progress_hook]
    }

    try:
        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        
        print(Fore.GREEN + "\nDownload completed successfully." + Style.RESET_ALL)
    
    except Exception as e:
        print(Fore.RED + f"An error occurred: {e}" + Style.RESET_ALL)

    print_footer()

def progress_hook(d):
    """Displays download progress."""
    if d['status'] == 'downloading':
        percent = d.get('downloaded_bytes', 0) / d.get('total_bytes', 1) * 100
        sys.stdout.write(f"\r{Fore.CYAN}Downloading: {percent:.2f}%{Style.RESET_ALL}")
        sys.stdout.flush()
    elif d['status'] == 'finished':
        sys.stdout.write(f"\r{Fore.GREEN}Download complete: 100.00%{Style.RESET_ALL}\n")
        sys.stdout.flush()

if __name__ == "__main__":
    download_youtube_video()
